// InstaGrab - Background Service Worker (Manifest V3)
const HELPER_BASE = 'http://127.0.0.1:18765';
let cachedToken = null;
let currentDownload = null; // { downloadId, state, progress, speed, eta, filename, error }
let activeChromeDownloadId = null; // Tracks active browser download for cancellation

// Auto-pair with Desktop Engine
async function getAuthToken() {
  if (cachedToken) return cachedToken;
  try {
    const resp = await fetch(`${HELPER_BASE}/api/pair/auto`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'InstaGrab'
      }
    });
    if (!resp.ok) throw new Error('Auto-pair failed: ' + resp.status);
    const data = await resp.json();
    cachedToken = data.token;
    return cachedToken;
  } catch (err) {
    console.warn('[InstaGrab Service Worker] Engine not responding:', err);
    return null;
  }
}

// Check if Desktop Engine is online
async function checkHealth() {
  try {
    const resp = await fetch(`${HELPER_BASE}/api/health`);
    if (!resp.ok) return { ok: false };
    const data = await resp.json();
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

// Sanitize filename for Chrome download API
function sanitizeFilename(name) {
  if (!name) return 'media_download.mp4';
  return name
    .replace(/[<>:"/\\|?*\uff1f\u29f8\u2044\x00-\x1f]/g, '_')
    .replace(/\s+/g, ' ')
    .trim();
}

// Helper: Trigger native browser download with full error reporting and state verification
function triggerBrowserDownload(fileUrl, filename) {
  return new Promise((resolve) => {
    if (!chrome.downloads || !chrome.downloads.download) {
      const err = 'Browser download permission blocked or missing. Please grant Downloads permission for InstaGrab in chrome://extensions.';
      console.warn('[InstaGrab]', err);
      resolve({ error: err });
      return;
    }

    try {
      chrome.downloads.download(
        {
          url: fileUrl,
          filename: sanitizeFilename(filename),
          conflictAction: 'uniquify',
          saveAs: false
        },
        (downloadId) => {
          if (chrome.runtime.lastError) {
            const errMsg = chrome.runtime.lastError.message || 'Unknown browser download error';
            console.warn('[InstaGrab] chrome.downloads.download error:', errMsg);
            resolve({ error: errMsg });
            return;
          }

          if (!downloadId) {
            resolve({ error: 'Browser failed to initialize download.' });
            return;
          }

          activeChromeDownloadId = downloadId;
          console.log('[InstaGrab] Browser download started, id:', downloadId);

          let timer = null;
          const onChangedListener = (delta) => {
            if (delta.id === downloadId) {
              if (delta.state && delta.state.current === 'complete') {
                chrome.downloads.onChanged.removeListener(onChangedListener);
                if (timer) clearTimeout(timer);
                activeChromeDownloadId = null;
                resolve({ success: true, downloadId });
              } else if (delta.state && delta.state.current === 'interrupted') {
                chrome.downloads.onChanged.removeListener(onChangedListener);
                if (timer) clearTimeout(timer);
                activeChromeDownloadId = null;
                const reason = delta.error ? delta.error.current : 'Download interrupted';
                resolve({ error: `Browser download interrupted (${reason})` });
              }
            }
          };

          chrome.downloads.onChanged.addListener(onChangedListener);

          // 45s safety timeout: verify state before assuming success
          timer = setTimeout(() => {
            chrome.downloads.onChanged.removeListener(onChangedListener);
            activeChromeDownloadId = null;
            chrome.downloads.search({ id: downloadId }, (items) => {
              if (items && items[0]) {
                if (items[0].state === 'interrupted') {
                  resolve({ error: `Browser download interrupted: ${items[0].error || 'Failed'}` });
                } else {
                  resolve({ success: true, downloadId });
                }
              } else {
                resolve({ success: true, downloadId });
              }
            });
          }, 45000);
        }
      );
    } catch (e) {
      resolve({ error: e.message || 'Exception occurred while initiating browser download' });
    }
  });
}

function normalizeMediaUrl(rawUrl) {
  if (!rawUrl) return rawUrl;
  try {
    let uStr = rawUrl.trim();
    if (!uStr.startsWith('http://') && !uStr.startsWith('https://')) {
      uStr = 'https://' + uStr;
    }
    const u = new URL(uStr);

    // 1. YouTube watch URLs: strip playlist and secondary params to prevent runaway playlist downloads
    if (u.hostname.includes('youtube.com') || u.hostname.includes('youtu.be')) {
      if (u.pathname === '/watch' || u.pathname === '/watch_popup') {
        const v = u.searchParams.get('v');
        if (v) return `https://www.youtube.com/watch?v=${v}`;
      }
      if (u.pathname.startsWith('/shorts/')) {
        const sMatch = u.pathname.match(/\/shorts\/([A-Za-z0-9_-]+)/);
        if (sMatch) return `https://www.youtube.com/shorts/${sMatch[1]}`;
      }
      if (u.hostname.includes('youtu.be')) {
        const id = u.pathname.replace(/^\/+/, '').split('/')[0];
        if (id) return `https://www.youtube.com/watch?v=${id}`;
      }
    }

    // 2. Instagram
    if (u.hostname.includes('instagram.com') || u.hostname.includes('instagr.am')) {
      const hlShortMatch = u.pathname.match(/\/s\/([A-Za-z0-9_-]+)/);
      if (hlShortMatch) {
        try {
          const cleanB64 = hlShortMatch[1].replace(/-/g, '+').replace(/_/g, '/');
          const paddedB64 = cleanB64 + '='.repeat((4 - (cleanB64.length % 4)) % 4);
          const decoded = atob(paddedB64);
          const matchId = decoded.match(/highlight:(\d+)/);
          if (matchId) {
            return `https://www.instagram.com/stories/highlights/${matchId[1]}/`;
          }
        } catch (_) {}
        return u.href;
      }
      if (u.pathname.includes('/stories/')) {
        return u.href;
      }
      const match = u.pathname.match(/\/(?:p|reel|reels|tv|share\/reel|share\/p)\/([A-Za-z0-9_-]+)/);
      if (match) {
        const type = u.pathname.includes('reel') ? 'reel' : (u.pathname.includes('tv') ? 'tv' : 'p');
        return `https://www.instagram.com/${type}/${match[1]}/`;
      }
    }

    // 3. Pinterest
    if (u.hostname.includes('pinterest.') || u.hostname.includes('pin.it')) {
      const pinMatch = u.pathname.match(/\/pin\/(\d+)/i);
      if (pinMatch) return `https://www.pinterest.com/pin/${pinMatch[1]}/`;
    }

    // 4. Envato Elements & AudioJungle (preserve instagrab_title query param if present)
    if (u.hostname.includes('envato.com') || u.hostname.includes('audiojungle.net')) {
      if (u.searchParams.has('instagrab_title')) return u.href;
      const cleanPath = u.pathname.replace(/\/+$/, '');
      if (cleanPath) return `${u.protocol}//${u.host}${cleanPath}`;
    }

    // 5. Epidemic Sound (preserve audiocdn & search/title query params)
    if (u.hostname.includes('epidemicsound.com') && !u.hostname.includes('audiocdn.')) {
      if (u.search) return u.href;
      const cleanPath = u.pathname.replace(/\/+$/, '');
      if (cleanPath) return `${u.protocol}//${u.host}${cleanPath}/`;
    }

    // 6. Spotify
    if (u.hostname.includes('spotify.com')) {
      const spMatch = u.pathname.match(/\/(?:intl-[a-zA-Z-]+\/)?(?:embed\/)?(track|playlist|album)\/([A-Za-z0-9]+)/);
      if (spMatch) {
        return `https://open.spotify.com/${spMatch[1]}/${spMatch[2]}`;
      }
    }
  } catch {}
  return rawUrl;
}

// Helper to broadcast progress to both active tab and popup runtime
function broadcastProgress(data, tabId) {
  if (tabId) {
    chrome.tabs.sendMessage(tabId, { action: 'downloadProgress', ...data }).catch(() => {});
  }
  chrome.runtime.sendMessage({ action: 'downloadProgress', ...data }).catch(() => {});
}

// Background poller that continues running regardless of whether popup is open
async function pollDownloadStatus(downloadId, token, tabId) {
  const startTime = Date.now();
  let completedFilename = null;
  let completedFiles = null;

  while (Date.now() - startTime < 300000) { // 5 minute timeout for large files
    await new Promise(r => setTimeout(r, 350));

    try {
      const sResp = await fetch(`${HELPER_BASE}/api/download/${downloadId}/status`, {
        headers: {
          'X-Requested-With': 'InstaGrab',
          'Authorization': `Bearer ${token}`
        }
      });

      if (sResp.ok) {
        const status = await sResp.json();
        
        currentDownload = {
          downloadId,
          state: status.state,
          progress: status.progress || 0,
          speed: status.speed || '',
          eta: status.eta || '',
          filename: status.filename || '',
          error: status.error || ''
        };

        broadcastProgress(currentDownload, tabId);

        if (status.state === 'complete') {
          completedFilename = status.filename;
          completedFiles = status.files;
          break;
        } else if (status.state === 'error') {
          currentDownload = {
            downloadId,
            state: 'error',
            error: status.error || 'Download failed during processing'
          };
          broadcastProgress(currentDownload, tabId);
          setTimeout(() => {
            if (currentDownload && currentDownload.downloadId === downloadId) currentDownload = null;
          }, 8000);
          return;
        }
      }
    } catch (pollErr) {
      console.warn('[InstaGrab] Status poll error:', pollErr);
    }
  }

  // Hand-off completed file(s) to native Chrome / Browser Download Manager with full error detection
  if (completedFiles && completedFiles.length > 1) {
    let failedCount = 0;
    let lastError = null;
    for (let i = 0; i < completedFiles.length; i++) {
      const f = completedFiles[i];
      const streamUrl = `${HELPER_BASE}/api/file/download/${encodeURIComponent(f)}?token=${token}`;
      const res = await triggerBrowserDownload(streamUrl, f);
      if (res && res.error) {
        failedCount++;
        lastError = res.error;
      }
      await new Promise(r => setTimeout(r, 350));
    }

    if (failedCount === completedFiles.length) {
      currentDownload = {
        downloadId,
        state: 'error',
        error: `Could not save to browser: ${lastError || 'Permission error'}. (Files are saved in Downloads\\InstaGrab on your PC).`
      };
      broadcastProgress(currentDownload, tabId);
      setTimeout(() => {
        if (currentDownload && currentDownload.downloadId === downloadId) currentDownload = null;
      }, 12000);
      return;
    }

    currentDownload = {
      downloadId,
      state: 'complete',
      progress: 100,
      filename: `${completedFiles.length - failedCount} files saved to browser downloads`
    };

    broadcastProgress(currentDownload, tabId);

    setTimeout(() => {
      if (currentDownload && currentDownload.downloadId === downloadId) currentDownload = null;
    }, 10000);
  } else if (completedFilename) {
    const streamUrl = `${HELPER_BASE}/api/file/download/${encodeURIComponent(completedFilename)}?token=${token}`;
    const res = await triggerBrowserDownload(streamUrl, completedFilename);

    if (res && res.error) {
      console.warn('[InstaGrab] Browser download hand-off failed:', res.error);
      currentDownload = {
        downloadId,
        state: 'error',
        error: `Could not save to browser: ${res.error}. (File is saved in Downloads\\InstaGrab on your PC).`,
        filename: completedFilename
      };
      broadcastProgress(currentDownload, tabId);
      setTimeout(() => {
        if (currentDownload && currentDownload.downloadId === downloadId) currentDownload = null;
      }, 12000);
      return;
    }

    currentDownload = {
      downloadId,
      state: 'complete',
      progress: 100,
      filename: completedFilename
    };

    broadcastProgress(currentDownload, tabId);

    setTimeout(() => {
      if (currentDownload && currentDownload.downloadId === downloadId) currentDownload = null;
    }, 10000);
  } else {
    // Neither completedFilename nor completedFiles was set (timeout or engine drop)
    currentDownload = {
      downloadId,
      state: 'error',
      error: 'Download timed out or Desktop Engine connection was interrupted.'
    };
    broadcastProgress(currentDownload, tabId);
    setTimeout(() => {
      if (currentDownload && currentDownload.downloadId === downloadId) currentDownload = null;
    }, 10000);
  }
}

// Asynchronous start download job with immediate handshake
async function startDownload(url, formatType, quality, tabId = null, options = {}) {
  url = normalizeMediaUrl(url);
  const isAudioPlatform = url && (
    url.includes('envato.com') ||
    url.includes('audiojungle.net') ||
    url.includes('envatousercontent.com') ||
    url.includes('epidemicsound.com') ||
    url.includes('spotify.com')
  );
  if (isAudioPlatform) {
    formatType = 'audio';
  }

  // Fallback to active tab ID if triggered from popup
  if (!tabId && chrome.tabs && chrome.tabs.query) {
    try {
      const activeTabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (activeTabs && activeTabs[0]) {
        tabId = activeTabs[0].id;
      } else {
        const anyTabs = await chrome.tabs.query({ active: true });
        if (anyTabs && anyTabs[0]) tabId = anyTabs[0].id;
      }
    } catch {}
  }

  let token = await getAuthToken();
  if (!token) {
    return { 
      success: false, 
      offline: true, 
      error: 'InstaGrab Desktop Engine is offline. Please launch InstaGrab on your PC!' 
    };
  }

  try {
    // 1. Submit download request to Desktop Engine (Zero cookies used)
    const downloadPayload = {
      url: url,
      format_type: formatType || 'video',
      quality: quality || 'best',
      as_zip: options.as_zip !== undefined ? options.as_zip : true
    };
    if (options.item_index !== undefined) {
      downloadPayload.item_index = options.item_index;
    }
    if (options.direct_media_url) {
      downloadPayload.direct_media_url = options.direct_media_url;
    }

    let resp = await fetch(`${HELPER_BASE}/api/download`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'InstaGrab',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(downloadPayload)
    });

    // If token expired, refresh and retry once
    if (resp.status === 401 || resp.status === 403) {
      cachedToken = null;
      token = await getAuthToken();
      if (!token) {
        return { 
          success: false, 
          offline: true, 
          error: 'Desktop Engine authentication failed.' 
        };
      }
      resp = await fetch(`${HELPER_BASE}/api/download`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'InstaGrab',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(downloadPayload)
      });
    }

    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({}));
      return { success: false, error: errData.error || 'Failed to start download' };
    }

    const { downloadId } = await resp.json();

    currentDownload = {
      downloadId,
      state: 'extracting',
      progress: 0,
      speed: '',
      eta: '',
      filename: ''
    };

    // Broadcast starting state immediately
    broadcastProgress(currentDownload, tabId);

    // Launch background status poller without awaiting so caller receives immediate ack
    pollDownloadStatus(downloadId, token, tabId);

    return { success: true, downloadId };

  } catch (err) {
    return { 
      success: false, 
      offline: true, 
      error: 'Cannot reach Desktop Engine. Ensure InstaGrab is running.' 
    };
  }
}

// Extract a clean PNG filename from an image URL
function extractPngFilename(srcUrl) {
  try {
    const urlObj = new URL(srcUrl);
    let pathname = urlObj.pathname;
    let rawName = pathname.split('/').pop() || 'image';
    rawName = decodeURIComponent(rawName).split('?')[0];
    const baseName = rawName.replace(/\.[a-zA-Z0-9]+$/, '') || 'image';
    const cleanName = baseName.replace(/[^a-zA-Z0-9_\-\s]/g, '_').trim() || 'image';
    return `${cleanName}.png`;
  } catch {
    return `image_${Date.now()}.png`;
  }
}

// Convert any image URL (WEBP, AVIF, JPG, SVG, etc.) to pure PNG Data URL in Service Worker
async function convertImageToPngDataUrl(imageUrl) {
  const resp = await fetch(imageUrl);
  if (!resp.ok) throw new Error('Failed to fetch image: ' + resp.status);
  const blob = await resp.blob();
  const bitmap = await createImageBitmap(blob);
  const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0);
  const pngBlob = await canvas.convertToBlob({ type: 'image/png' });
  const buffer = await pngBlob.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return 'data:image/png;base64,' + btoa(binary);
}

// Handle Right-Click "Save Image as PNG"
async function handleSaveImageAsPng(srcUrl, tab) {
  const tabId = tab ? tab.id : null;
  const filename = extractPngFilename(srcUrl);

  if (tabId) {
    chrome.tabs.sendMessage(tabId, {
      action: 'downloadProgress',
      state: 'downloading',
      progress: 25,
      speed: 'Converting to PNG',
      filename: filename
    }).catch(() => {});
  }

  // 1. Try delegating to content script first (can use in-memory rendered DOM <img> without network re-fetch)
  if (tabId) {
    try {
      const result = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tabId, { action: 'convertImageToPng', srcUrl }, (res) => {
          if (chrome.runtime.lastError || !res || !res.dataUrl) {
            resolve(null);
          } else {
            resolve(res);
          }
        });
      });

      if (result && result.dataUrl) {
        await triggerBrowserDownload(result.dataUrl, filename);
        chrome.tabs.sendMessage(tabId, {
          action: 'downloadProgress',
          state: 'complete',
          progress: 100,
          filename: filename
        }).catch(() => {});
        return;
      }
    } catch (tabErr) {
      console.warn('[InstaGrab] Tab image conversion fallback to background:', tabErr);
    }
  }

  // 2. Fallback: Convert via Service Worker OffscreenCanvas
  try {
    const dataUrl = await convertImageToPngDataUrl(srcUrl);
    await triggerBrowserDownload(dataUrl, filename);

    if (tabId) {
      chrome.tabs.sendMessage(tabId, {
        action: 'downloadProgress',
        state: 'complete',
        progress: 100,
        filename: filename
      }).catch(() => {});
    }
  } catch (err) {
    console.error('[InstaGrab] Failed to convert image to PNG:', err);
    if (tabId) {
      chrome.tabs.sendMessage(tabId, {
        action: 'downloadProgress',
        state: 'error',
        error: 'Failed to convert image to PNG'
      }).catch(() => {});
    }
  }
}

// Register Context Menu on Install & Startup
function setupContextMenu() {
  if (chrome.contextMenus && chrome.contextMenus.create) {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: 'instagrab-save-as-png',
        title: 'Save Image as PNG (InstaGrab)',
        contexts: ['image']
      }, () => {
        if (chrome.runtime.lastError) {
          console.warn('[InstaGrab] Context menu setup:', chrome.runtime.lastError.message);
        }
      });
    });
  }
}

chrome.runtime.onInstalled.addListener(setupContextMenu);
chrome.runtime.onStartup.addListener(setupContextMenu);
setupContextMenu();

// Context Menu Click Listener
if (chrome.contextMenus && chrome.contextMenus.onClicked) {
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'instagrab-save-as-png' && info.srcUrl) {
      handleSaveImageAsPng(info.srcUrl, tab);
    }
  });
}


// Message Listener for Content Scripts & Popup
// Direct Image Download (High-Res Browser Fetch + Native Save)
async function handleDirectDownloadImage(srcUrl, filename, tabId = null) {
  const safeFilename = sanitizeFilename(filename || extractPngFilename(srcUrl));
  if (tabId) {
    chrome.tabs.sendMessage(tabId, {
      action: 'downloadProgress',
      state: 'downloading',
      progress: 30,
      speed: 'Preparing high-res download...',
      filename: safeFilename
    }).catch(() => {});
  }

  try {
    const dataUrl = await convertImageToPngDataUrl(srcUrl);

    if (tabId) {
      chrome.tabs.sendMessage(tabId, {
        action: 'downloadProgress',
        state: 'downloading',
        progress: 80,
        speed: 'Saving to browser...',
        filename: safeFilename
      }).catch(() => {});
    }

    const res = await triggerBrowserDownload(dataUrl, safeFilename);
    if (res && res.error) {
      throw new Error(res.error);
    }

    if (tabId) {
      chrome.tabs.sendMessage(tabId, {
        action: 'downloadProgress',
        state: 'complete',
        progress: 100,
        filename: safeFilename
      }).catch(() => {});
    }

    // Also trigger Desktop Engine backup in background if available
    getAuthToken().then(token => {
      if (token) {
        fetch(`${HELPER_BASE}/api/download`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'InstaGrab',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            url: srcUrl,
            direct_media_url: srcUrl,
            format_type: 'video',
            quality: 'best'
          })
        }).catch(() => {});
      }
    }).catch(() => {});

    return { success: true, filename: safeFilename };
  } catch (err) {
    console.error('[InstaGrab] directDownloadImage error:', err);
    if (tabId) {
      chrome.tabs.sendMessage(tabId, {
        action: 'downloadProgress',
        state: 'error',
        error: err.message || 'Failed to download image'
      }).catch(() => {});
    }
    return { success: false, error: err.message || 'Failed to download image' };
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkHealth') {
    checkHealth().then(sendResponse);
    return true;
  }
  if (request.action === 'getActiveDownload') {
    sendResponse(currentDownload);
    return true;
  }
  if (request.action === 'fetchPngDataUrl') {
    convertImageToPngDataUrl(request.url)
      .then((dataUrl) => sendResponse({ success: true, dataUrl }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (request.action === 'download') {
    const tabId = sender.tab ? sender.tab.id : null;
    startDownload(request.url, request.format_type, request.quality, tabId, request.options || {}).then(sendResponse);
    return true;
  }
  if (request.action === 'cancelDownload') {
    cancelActiveDownload().then(sendResponse);
    return true;
  }
});

// Cancel active download in desktop helper and in browser
async function cancelActiveDownload() {
  if (!currentDownload || !currentDownload.downloadId) {
    return { success: false, error: 'No active download to cancel' };
  }
  const dlId = currentDownload.downloadId;
  const token = await getAuthToken();

  // 1. Cancel in desktop helper engine
  if (token) {
    try {
      await fetch(`${HELPER_BASE}/api/download/${dlId}/cancel`, {
        method: 'POST',
        headers: {
          'X-Requested-With': 'InstaGrab',
          'Authorization': `Bearer ${token}`
        }
      });
    } catch (e) {
      console.warn('[InstaGrab] Error cancelling helper download:', e);
    }
  }

  // 2. Cancel in Chrome downloads if browser stream is active
  if (activeChromeDownloadId && chrome.downloads && chrome.downloads.cancel) {
    try {
      chrome.downloads.cancel(activeChromeDownloadId, () => {});
    } catch (_) {}
    activeChromeDownloadId = null;
  }

  // 3. Update state and broadcast cancellation
  currentDownload = {
    downloadId: dlId,
    state: 'error',
    error: 'Download cancelled by user'
  };
  broadcastProgress(currentDownload, null);

  setTimeout(() => {
    if (currentDownload && currentDownload.downloadId === dlId) {
      currentDownload = null;
    }
  }, 4000);

  return { success: true };
}
